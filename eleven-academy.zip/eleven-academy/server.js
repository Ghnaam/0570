require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');

const { attachUser } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// ============== أمان عام ==============
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      objectSrc: ["'none'"],
      frameAncestors: ["'self'"]
    }
  }
}));
app.disable('x-powered-by');

// حد عام لكل الطلبات لمنع إساءة الاستخدام
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 500, standardHeaders: true, legacyHeaders: false }));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());
app.use(attachUser);

// ============== الملفات الثابتة (الواجهة الأمامية) ==============
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

// ============== مسارات الـ API ==============
app.use('/api/auth', require('./routes/auth'));
app.use('/api/news', require('./routes/news'));
app.use('/api/players', require('./routes/players'));
app.use('/api/matches', require('./routes/matches'));
app.use('/api/comments', require('./routes/comments'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/admin', require('./routes/admin'));

// ============== معالجة الأخطاء العامة (لا تُظهر تفاصيل تقنية للمستخدم) ==============
app.use((err, req, res, next) => {
  console.error(err);
  if (err.message && err.message.includes('نوع الملف')) {
    return res.status(400).json({ error: err.message });
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'حجم الملف كبير جدًا (الحد الأقصى 3MB)' });
  }
  res.status(500).json({ error: 'حدث خطأ في الخادم' });
});

// أي مسار غير معروف يُعاد توجيهه للصفحة الرئيسية (لصفحات الواجهة)
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, 'public', '404.html'), (err) => {
    if (err) res.status(404).send('الصفحة غير موجودة');
  });
});

app.listen(PORT, () => {
  console.log(`✅ موقع أكاديمية Eleven يعمل على المنفذ ${PORT}`);
  console.log(`   افتح المتصفح على: http://localhost:${PORT}`);
});
