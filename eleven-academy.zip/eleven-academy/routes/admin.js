const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAdmin); // كل المسارات هنا للإدارة فقط

// ============== إحصائيات عامة للوحة التحكم ==============
router.get('/stats', (req, res) => {
  const stats = {
    members: db.prepare(`SELECT COUNT(*) c FROM users WHERE role='member'`).get().c,
    news: db.prepare(`SELECT COUNT(*) c FROM news`).get().c,
    players: db.prepare(`SELECT COUNT(*) c FROM players`).get().c,
    matches: db.prepare(`SELECT COUNT(*) c FROM matches`).get().c,
    comments: db.prepare(`SELECT COUNT(*) c FROM comments`).get().c,
    upcoming_matches: db.prepare(`SELECT COUNT(*) c FROM matches WHERE status='upcoming'`).get().c
  };
  res.json({ stats });
});

// ============== إدارة الأعضاء ==============
router.get('/users', (req, res) => {
  const users = db.prepare(`SELECT id, name, email, role, is_banned, created_at FROM users ORDER BY created_at DESC`).all();
  res.json({ users });
});

router.put('/users/:id/ban', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'العضو غير موجود' });
  if (user.role === 'admin') return res.status(400).json({ error: 'لا يمكن إيقاف حساب إدارة' });
  db.prepare('UPDATE users SET is_banned = ? WHERE id = ?').run(user.is_banned ? 0 : 1, req.params.id);
  res.json({ ok: true });
});

router.delete('/users/:id', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'العضو غير موجود' });
  if (user.role === 'admin') return res.status(400).json({ error: 'لا يمكن حذف حساب إدارة' });
  db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ============== ترقية عضو إلى مشرف إداري إضافي ==============
router.put('/users/:id/promote', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'العضو غير موجود' });
  db.prepare(`UPDATE users SET role = 'admin' WHERE id = ?`).run(req.params.id);
  res.json({ ok: true });
});

// ============== كل التعليقات (لإدارة المحتوى والإشراف) ==============
router.get('/comments', (req, res) => {
  const comments = db.prepare(`
    SELECT comments.id, comments.content, comments.is_hidden, comments.created_at,
           users.name AS user_name, matches.opponent AS match_opponent, comments.match_id
    FROM comments
    JOIN users ON users.id = comments.user_id
    JOIN matches ON matches.id = comments.match_id
    ORDER BY comments.created_at DESC
  `).all();
  res.json({ comments });
});

// ============== تغيير كلمة مرور حساب الإدارة الحالي ==============
router.put('/change-password', (req, res) => {
  const { current_password, new_password } = req.body;
  if (!new_password || new_password.length < 8) {
    return res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل' });
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!bcrypt.compareSync(current_password || '', user.password_hash)) {
    return res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة' });
  }
  const hash = bcrypt.hashSync(new_password, 12);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
