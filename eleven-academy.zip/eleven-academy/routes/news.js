const express = require('express');
const sanitizeHtml = require('sanitize-html');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

function clean(text) {
  return sanitizeHtml(text, { allowedTags: ['b', 'i', 'em', 'strong', 'br', 'p', 'ul', 'ol', 'li', 'a'], allowedAttributes: { a: ['href', 'target', 'rel'] } });
}

// ============== عرض كل الأخبار المنشورة (عام) ==============
router.get('/', (req, res) => {
  const news = db.prepare(`
    SELECT news.id, news.title, news.content, news.image, news.created_at, users.name AS author
    FROM news LEFT JOIN users ON users.id = news.author_id
    WHERE news.is_published = 1
    ORDER BY news.created_at DESC
  `).all();
  res.json({ news });
});

// ============== كل الأخبار (منشورة وغير منشورة) - للإدارة فقط ==============
router.get('/admin/all', requireAdmin, (req, res) => {
  const news = db.prepare(`
    SELECT news.id, news.title, news.content, news.image, news.is_published, news.created_at, users.name AS author
    FROM news LEFT JOIN users ON users.id = news.author_id
    ORDER BY news.created_at DESC
  `).all();
  res.json({ news });
});

router.get('/:id', (req, res) => {
  const item = db.prepare('SELECT * FROM news WHERE id = ? AND is_published = 1').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'الخبر غير موجود' });
  res.json({ news: item });
});

// ============== إضافة خبر (إدارة) ==============
router.post('/', requireAdmin, upload.single('image'),
  body('title').trim().isLength({ min: 3, max: 150 }),
  body('content').trim().isLength({ min: 10 }),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'عنوان أو محتوى الخبر غير صالح' });

    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const info = db.prepare(`INSERT INTO news (title, content, image, author_id) VALUES (?, ?, ?, ?)`)
      .run(req.body.title.trim(), clean(req.body.content), image, req.user.id);
    res.json({ ok: true, id: info.lastInsertRowid });
  }
);

// ============== تعديل خبر (إدارة) ==============
router.put('/:id', requireAdmin, upload.single('image'), (req, res) => {
  const existing = db.prepare('SELECT * FROM news WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'الخبر غير موجود' });

  const title = req.body.title ? req.body.title.trim() : existing.title;
  const content = req.body.content ? clean(req.body.content) : existing.content;
  const isPublished = req.body.is_published !== undefined ? (req.body.is_published ? 1 : 0) : existing.is_published;
  const image = req.file ? `/uploads/${req.file.filename}` : existing.image;

  db.prepare('UPDATE news SET title=?, content=?, image=?, is_published=? WHERE id=?')
    .run(title, content, image, isPublished, req.params.id);
  res.json({ ok: true });
});

// ============== حذف خبر (إدارة) ==============
router.delete('/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM news WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
