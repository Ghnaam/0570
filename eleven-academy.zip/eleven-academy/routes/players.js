const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

router.get('/', (req, res) => {
  const players = db.prepare('SELECT * FROM players WHERE is_active = 1 ORDER BY number ASC').all();
  res.json({ players });
});

router.post('/', requireAdmin, upload.single('photo'),
  body('name').trim().isLength({ min: 2, max: 60 }),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'اسم اللاعب غير صالح' });

    const photo = req.file ? `/uploads/${req.file.filename}` : null;
    const { name, position, number, age, bio } = req.body;
    const info = db.prepare(`INSERT INTO players (name, position, number, age, photo, bio) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(name.trim(), position || null, number || null, age || null, photo, bio || null);
    res.json({ ok: true, id: info.lastInsertRowid });
  }
);

router.put('/:id', requireAdmin, upload.single('photo'), (req, res) => {
  const existing = db.prepare('SELECT * FROM players WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'اللاعب غير موجود' });

  const photo = req.file ? `/uploads/${req.file.filename}` : existing.photo;
  const name = req.body.name ? req.body.name.trim() : existing.name;
  const position = req.body.position ?? existing.position;
  const number = req.body.number ?? existing.number;
  const age = req.body.age ?? existing.age;
  const bio = req.body.bio ?? existing.bio;
  const isActive = req.body.is_active !== undefined ? (req.body.is_active ? 1 : 0) : existing.is_active;

  db.prepare('UPDATE players SET name=?, position=?, number=?, age=?, photo=?, bio=?, is_active=? WHERE id=?')
    .run(name, position, number, age, photo, bio, isActive, req.params.id);
  res.json({ ok: true });
});

router.delete('/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM players WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
