const express = require('express');
const { body, validationResult } = require('express-validator');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

// ============== كل المباريات ==============
router.get('/', (req, res) => {
  const { status } = req.query;
  let matches;
  if (status && ['upcoming', 'live', 'finished'].includes(status)) {
    matches = db.prepare('SELECT * FROM matches WHERE status = ? ORDER BY match_date ASC').all(status);
  } else {
    matches = db.prepare('SELECT * FROM matches ORDER BY match_date ASC').all();
  }
  res.json({ matches });
});

// ============== أقرب مباراة قادمة (لعرضها في الواجهة الرئيسية) ==============
router.get('/next', (req, res) => {
  const match = db.prepare(`
    SELECT * FROM matches
    WHERE status = 'upcoming'
    ORDER BY match_date ASC LIMIT 1
  `).get();
  res.json({ match: match || null });
});

router.get('/:id', (req, res) => {
  const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(req.params.id);
  if (!match) return res.status(404).json({ error: 'المباراة غير موجودة' });
  res.json({ match });
});

// ============== إضافة مباراة (إدارة) ==============
router.post('/', requireAdmin,
  body('opponent').trim().isLength({ min: 2, max: 80 }),
  body('match_date').isISO8601().withMessage('تاريخ غير صالح'),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

    const { opponent, match_date, location, status, notes } = req.body;
    const info = db.prepare(`INSERT INTO matches (opponent, match_date, location, status, notes) VALUES (?, ?, ?, ?, ?)`)
      .run(opponent.trim(), match_date, location || null, status || 'upcoming', notes || null);
    res.json({ ok: true, id: info.lastInsertRowid });
  }
);

// ============== تعديل مباراة / تحديث النتيجة (إدارة) ==============
router.put('/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM matches WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'المباراة غير موجودة' });

  const opponent = req.body.opponent ?? existing.opponent;
  const match_date = req.body.match_date ?? existing.match_date;
  const location = req.body.location ?? existing.location;
  const status = req.body.status ?? existing.status;
  const score_home = req.body.score_home ?? existing.score_home;
  const score_away = req.body.score_away ?? existing.score_away;
  const notes = req.body.notes ?? existing.notes;

  db.prepare(`UPDATE matches SET opponent=?, match_date=?, location=?, status=?, score_home=?, score_away=?, notes=? WHERE id=?`)
    .run(opponent, match_date, location, status, score_home, score_away, notes, req.params.id);
  res.json({ ok: true });
});

router.delete('/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM matches WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
