const express = require('express');
const db = require('../db');
const { requireAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

function getAllSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const obj = {};
  for (const r of rows) obj[r.key] = r.value;
  return obj;
}

// ============== عرض الإعدادات (عام - تُستخدم لبناء الواجهة) ==============
router.get('/', (req, res) => {
  res.json({ settings: getAllSettings() });
});

// ============== تحديث إعدادات نصية (اسم النادي، الوصف، بيانات الراعي) (إدارة) ==============
router.put('/', requireAdmin, (req, res) => {
  const allowedKeys = ['club_name', 'club_description', 'sponsor_name', 'sponsor_link', 'sponsor_enabled'];
  const update = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  const tx = db.transaction((entries) => {
    for (const [key, value] of entries) update.run(key, String(value));
  });
  const entries = Object.entries(req.body).filter(([k]) => allowedKeys.includes(k));
  tx(entries);
  res.json({ ok: true, settings: getAllSettings() });
});

// ============== رفع شعار النادي (إدارة) ==============
router.post('/logo', requireAdmin, upload.single('logo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'الرجاء اختيار صورة' });
  const url = `/uploads/${req.file.filename}`;
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run('club_logo', url);
  res.json({ ok: true, url });
});

// ============== رفع شعار الراعي الرسمي (إدارة) ==============
router.post('/sponsor-logo', requireAdmin, upload.single('logo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'الرجاء اختيار صورة' });
  const url = `/uploads/${req.file.filename}`;
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run('sponsor_logo', url);
  res.json({ ok: true, url });
});

module.exports = router;
