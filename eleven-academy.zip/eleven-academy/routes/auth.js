const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { signToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

// حماية من محاولات تخمين كلمة المرور (brute force)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'محاولات كثيرة جدًا، حاول مرة أخرى بعد قليل' }
});

const cookieOpts = {
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 7 * 24 * 60 * 60 * 1000
};

// ============== تسجيل عضو جديد ==============
router.post('/register',
  authLimiter,
  body('name').trim().isLength({ min: 2, max: 50 }).withMessage('الاسم يجب أن يكون بين 2 و50 حرفًا'),
  body('email').trim().isEmail().withMessage('بريد إلكتروني غير صالح').normalizeEmail(),
  body('password').isLength({ min: 8 }).withMessage('كلمة المرور يجب أن تكون 8 أحرف على الأقل'),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

    const { name, email, password } = req.body;
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) return res.status(409).json({ error: 'هذا البريد الإلكتروني مسجل مسبقًا' });

    const hash = bcrypt.hashSync(password, 12);
    const info = db.prepare(`INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'member')`)
      .run(name, email, hash);

    const user = { id: info.lastInsertRowid, role: 'member' };
    const token = signToken(user);
    res.cookie('token', token, cookieOpts);
    res.json({ ok: true, user: { id: user.id, name, email, role: 'member' } });
  }
);

// ============== تسجيل الدخول (أعضاء وإدارة) ==============
router.post('/login',
  authLimiter,
  body('email').trim().isEmail().normalizeEmail(),
  body('password').notEmpty(),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });

    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    if (user.is_banned) return res.status(403).json({ error: 'تم إيقاف هذا الحساب' });

    const match = bcrypt.compareSync(password, user.password_hash);
    if (!match) return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });

    const token = signToken(user);
    res.cookie('token', token, cookieOpts);
    res.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, role: user.role, avatar: user.avatar } });
  }
);

// ============== تسجيل الخروج ==============
router.post('/logout', (req, res) => {
  res.clearCookie('token', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
  res.json({ ok: true });
});

// ============== بيانات المستخدم الحالي ==============
router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
