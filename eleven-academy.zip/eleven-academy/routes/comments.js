const express = require('express');
const sanitizeHtml = require('sanitize-html');
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// حد لعدد التعليقات لمنع الإزعاج (السبام)
const commentLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'أرسلت تعليقات كثيرة جدًا، انتظر قليلًا قبل المحاولة مجددًا' }
});

// ============== عرض تعليقات مباراة معيّنة (عام) ==============
router.get('/match/:matchId', (req, res) => {
  const comments = db.prepare(`
    SELECT comments.id, comments.content, comments.created_at, comments.user_id,
           users.name AS user_name, users.avatar AS user_avatar
    FROM comments
    JOIN users ON users.id = comments.user_id
    WHERE comments.match_id = ? AND comments.is_hidden = 0
    ORDER BY comments.created_at ASC
  `).all(req.params.matchId);
  res.json({ comments });
});

// ============== إضافة تعليق (أعضاء مسجلون فقط) ==============
router.post('/match/:matchId',
  requireAuth,
  commentLimiter,
  body('content').trim().isLength({ min: 1, max: 500 }).withMessage('التعليق يجب ألا يتجاوز 500 حرف'),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

    const match = db.prepare('SELECT id FROM matches WHERE id = ?').get(req.params.matchId);
    if (!match) return res.status(404).json({ error: 'المباراة غير موجودة' });

    const clean = sanitizeHtml(req.body.content, { allowedTags: [], allowedAttributes: {} });
    const info = db.prepare('INSERT INTO comments (match_id, user_id, content) VALUES (?, ?, ?)')
      .run(req.params.matchId, req.user.id, clean);

    res.json({
      ok: true,
      comment: { id: info.lastInsertRowid, content: clean, user_name: req.user.name, user_id: req.user.id, created_at: new Date().toISOString() }
    });
  }
);

// ============== حذف تعليق (صاحبه أو الإدارة) ==============
router.delete('/:id', requireAuth, (req, res) => {
  const comment = db.prepare('SELECT * FROM comments WHERE id = ?').get(req.params.id);
  if (!comment) return res.status(404).json({ error: 'التعليق غير موجود' });
  if (comment.user_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'لا تملك صلاحية حذف هذا التعليق' });
  }
  db.prepare('DELETE FROM comments WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ============== إخفاء/إظهار تعليق (إدارة) — بديل أهدأ من الحذف النهائي ==============
router.put('/:id/hide', requireAdmin, (req, res) => {
  const comment = db.prepare('SELECT * FROM comments WHERE id = ?').get(req.params.id);
  if (!comment) return res.status(404).json({ error: 'التعليق غير موجود' });
  db.prepare('UPDATE comments SET is_hidden = ? WHERE id = ?').run(comment.is_hidden ? 0 : 1, req.params.id);
  res.json({ ok: true });
});

module.exports = router;
