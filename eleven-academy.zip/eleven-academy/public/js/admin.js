let CURRENT_MATCHES = [];

async function initAdmin() {
  try {
    const { user } = await api('/auth/me');
    if (!user || user.role !== 'admin') throw new Error('forbidden');
    window.SITE.user = user;
  } catch (e) {
    location.href = '/login.html';
    return;
  }

  const { settings } = await api('/settings');
  window.SITE.settings = settings;
  document.getElementById('sideLogo').src = settings.club_logo || '/uploads/default-logo.svg';
  document.getElementById('currentLogo').src = settings.club_logo || '/uploads/default-logo.svg';
  document.querySelector('[name="club_name"]').value = settings.club_name || '';
  document.querySelector('[name="club_description"]').value = settings.club_description || '';
  document.getElementById('sponsorEnabled').checked = settings.sponsor_enabled === '1';
  document.querySelector('[name="sponsor_name"]').value = settings.sponsor_name || '';
  document.querySelector('[name="sponsor_link"]').value = settings.sponsor_link || '';
  if (settings.sponsor_logo) {
    const img = document.getElementById('currentSponsorLogo');
    img.src = settings.sponsor_logo; img.style.display = 'block';
  }

  document.getElementById('guardScreen').style.display = 'none';
  document.getElementById('adminLayout').style.display = 'flex';

  setupNav();
  setupForms();
  await loadPanel('dashboard');
}

// ============== التنقل بين الألواح ==============
function setupNav() {
  document.querySelectorAll('.admin-sidebar nav a[data-panel]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.admin-sidebar nav a').forEach(a => a.classList.remove('active'));
      link.classList.add('active');
      document.querySelectorAll('.admin-panel').forEach(p => p.classList.remove('active'));
      document.getElementById('panel-' + link.dataset.panel).classList.add('active');
      document.getElementById('panelTitle').textContent = link.textContent.trim();
      loadPanel(link.dataset.panel);
      document.getElementById('sidebar').classList.remove('open');
    });
  });

  document.getElementById('logoutBtn').addEventListener('click', async (e) => {
    e.preventDefault();
    await api('/auth/logout', { method: 'POST' });
    location.href = '/';
  });

  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });
  if (window.innerWidth <= 900) document.getElementById('sidebarToggle').style.display = 'block';
  window.addEventListener('resize', () => {
    document.getElementById('sidebarToggle').style.display = window.innerWidth <= 900 ? 'block' : 'none';
  });
}

async function loadPanel(name) {
  if (name === 'dashboard') return loadDashboard();
  if (name === 'news') return loadNewsTable();
  if (name === 'players') return loadPlayersTable();
  if (name === 'matches') return loadMatchesTable();
  if (name === 'comments') return loadCommentsTable();
  if (name === 'users') return loadUsersTable();
}

// ============== لوحة الإحصائيات ==============
async function loadDashboard() {
  const { stats } = await api('/admin/stats');
  const items = [
    ['الأعضاء', stats.members], ['الأخبار', stats.news], ['اللاعبون', stats.players],
    ['المباريات', stats.matches], ['التعليقات', stats.comments], ['مباريات قادمة', stats.upcoming_matches]
  ];
  document.getElementById('statsGrid').innerHTML = items.map(([label, value]) => `
    <div class="stat-card"><div class="value">${value}</div><div class="label">${label}</div></div>`).join('');
}

// ============== الأخبار ==============
async function loadNewsTable() {
  const { news } = await api('/news/admin/all');
  renderNewsTable(news);
}
function renderNewsTable(news) {
  const body = document.getElementById('newsTableBody');
  if (!news.length) { body.innerHTML = `<tr><td colspan="5"><div class="empty-state">لا توجد أخبار</div></td></tr>`; return; }
  body.innerHTML = news.map(n => `
    <tr>
      <td class="wrap">${escapeHtml(n.title)}</td>
      <td>${escapeHtml(n.author || '—')}</td>
      <td>${timeAgo(n.created_at)}</td>
      <td>${n.is_published !== 0 ? '✅' : '❌'}</td>
      <td>
        <button class="btn btn-sm" onclick='openNewsModal(${JSON.stringify(n).replace(/'/g, "&#39;")})'>تعديل</button>
        <button class="btn btn-sm btn-danger" onclick="deleteNews(${n.id})">حذف</button>
      </td>
    </tr>`).join('');
}
function openNewsModal(n) {
  const form = document.getElementById('newsForm');
  form.reset();
  document.getElementById('newsModalTitle').textContent = n ? 'تعديل خبر' : 'إضافة خبر';
  form.id.value = n ? n.id : '';
  if (n) {
    form.title.value = n.title;
    form.content.value = n.content;
    form.is_published.checked = !!n.is_published;
  }
  openModal('newsModal');
}
async function deleteNews(id) {
  if (!confirm('حذف هذا الخبر نهائيًا؟')) return;
  try { await api(`/news/${id}`, { method: 'DELETE' }); toast('تم حذف الخبر'); loadNewsTable(); }
  catch (e) { toast(e.message, 'error'); }
}

// ============== اللاعبون ==============
async function loadPlayersTable() {
  const { players } = await api('/players');
  const body = document.getElementById('playersTableBody');
  if (!players.length) { body.innerHTML = `<tr><td colspan="5"><div class="empty-state">لا يوجد لاعبون</div></td></tr>`; return; }
  body.innerHTML = players.map(p => `
    <tr>
      <td>${p.number ?? '—'}</td>
      <td>${escapeHtml(p.name)}</td>
      <td>${escapeHtml(p.position || '—')}</td>
      <td>${p.age ?? '—'}</td>
      <td>
        <button class="btn btn-sm" onclick='openPlayerModal(${JSON.stringify(p).replace(/'/g, "&#39;")})'>تعديل</button>
        <button class="btn btn-sm btn-danger" onclick="deletePlayer(${p.id})">حذف</button>
      </td>
    </tr>`).join('');
}
function openPlayerModal(p) {
  const form = document.getElementById('playerForm');
  form.reset();
  document.getElementById('playerModalTitle').textContent = p ? 'تعديل لاعب' : 'إضافة لاعب';
  form.id.value = p ? p.id : '';
  if (p) {
    form.name.value = p.name; form.position.value = p.position || '';
    form.number.value = p.number || ''; form.age.value = p.age || ''; form.bio.value = p.bio || '';
  }
  openModal('playerModal');
}
async function deletePlayer(id) {
  if (!confirm('حذف هذا اللاعب؟')) return;
  try { await api(`/players/${id}`, { method: 'DELETE' }); toast('تم حذف اللاعب'); loadPlayersTable(); }
  catch (e) { toast(e.message, 'error'); }
}

// ============== المباريات ==============
async function loadMatchesTable() {
  const { matches } = await api('/matches');
  CURRENT_MATCHES = matches;
  const body = document.getElementById('matchesTableBody');
  if (!matches.length) { body.innerHTML = `<tr><td colspan="5"><div class="empty-state">لا توجد مباريات</div></td></tr>`; return; }
  const statusLabel = { upcoming: 'قادمة', live: 'جارية', finished: 'انتهت' };
  body.innerHTML = matches.map(m => `
    <tr>
      <td>${escapeHtml(m.opponent)}</td>
      <td>${formatMatchDate(m.match_date)}</td>
      <td>${statusLabel[m.status]}</td>
      <td>${m.score_home !== null && m.score_home !== undefined ? m.score_home + ' - ' + m.score_away : '—'}</td>
      <td>
        <button class="btn btn-sm" onclick="openMatchModalById(${m.id})">تعديل</button>
        <button class="btn btn-sm btn-danger" onclick="deleteMatch(${m.id})">حذف</button>
      </td>
    </tr>`).join('');
}
function openMatchModalById(id) {
  const m = CURRENT_MATCHES.find(x => x.id === id);
  openMatchModal(m);
}
function openMatchModal(m) {
  const form = document.getElementById('matchForm');
  form.reset();
  document.getElementById('matchModalTitle').textContent = m ? 'تعديل مباراة' : 'إضافة مباراة';
  form.id.value = m ? m.id : '';
  if (m) {
    form.opponent.value = m.opponent;
    form.match_date.value = m.match_date ? m.match_date.slice(0, 16) : '';
    form.location.value = m.location || '';
    form.status.value = m.status;
    form.score_home.value = m.score_home ?? '';
    form.score_away.value = m.score_away ?? '';
  }
  openModal('matchModal');
}
async function deleteMatch(id) {
  if (!confirm('حذف هذه المباراة وكل تعليقاتها؟')) return;
  try { await api(`/matches/${id}`, { method: 'DELETE' }); toast('تم حذف المباراة'); loadMatchesTable(); }
  catch (e) { toast(e.message, 'error'); }
}

// ============== التعليقات ==============
async function loadCommentsTable() {
  const { comments } = await api('/admin/comments');
  const body = document.getElementById('commentsTableBody');
  if (!comments.length) { body.innerHTML = `<tr><td colspan="5"><div class="empty-state">لا توجد تعليقات</div></td></tr>`; return; }
  body.innerHTML = comments.map(c => `
    <tr>
      <td>${escapeHtml(c.user_name)}</td>
      <td>${escapeHtml(c.match_opponent)}</td>
      <td class="wrap">${escapeHtml(c.content)}</td>
      <td>${c.is_hidden ? '🙈 مخفي' : '👁 ظاهر'}</td>
      <td>
        <button class="btn btn-sm" onclick="toggleHideComment(${c.id})">${c.is_hidden ? 'إظهار' : 'إخفاء'}</button>
        <button class="btn btn-sm btn-danger" onclick="deleteCommentAdmin(${c.id})">حذف</button>
      </td>
    </tr>`).join('');
}
async function toggleHideComment(id) {
  try { await api(`/comments/${id}/hide`, { method: 'PUT' }); loadCommentsTable(); }
  catch (e) { toast(e.message, 'error'); }
}
async function deleteCommentAdmin(id) {
  if (!confirm('حذف هذا التعليق نهائيًا؟')) return;
  try { await api(`/comments/${id}`, { method: 'DELETE' }); toast('تم حذف التعليق'); loadCommentsTable(); }
  catch (e) { toast(e.message, 'error'); }
}

// ============== الأعضاء ==============
async function loadUsersTable() {
  const { users } = await api('/admin/users');
  const body = document.getElementById('usersTableBody');
  body.innerHTML = users.map(u => `
    <tr>
      <td>${escapeHtml(u.name)}</td>
      <td>${escapeHtml(u.email)}</td>
      <td>${u.role === 'admin' ? 'إدارة' : 'عضو'}</td>
      <td>${u.is_banned ? '⛔ موقوف' : '✅ نشط'}</td>
      <td>${new Date(u.created_at).toLocaleDateString('ar-EG')}</td>
      <td>
        ${u.role !== 'admin' ? `
          <button class="btn btn-sm" onclick="toggleBanUser(${u.id})">${u.is_banned ? 'إلغاء الإيقاف' : 'إيقاف'}</button>
          <button class="btn btn-sm" onclick="promoteUser(${u.id})">ترقية لإدارة</button>
          <button class="btn btn-sm btn-danger" onclick="deleteUser(${u.id})">حذف</button>` : '<span style="color:var(--gray-500);">—</span>'}
      </td>
    </tr>`).join('');
}
async function toggleBanUser(id) {
  try { await api(`/admin/users/${id}/ban`, { method: 'PUT' }); loadUsersTable(); }
  catch (e) { toast(e.message, 'error'); }
}
async function promoteUser(id) {
  if (!confirm('ترقية هذا العضو ليصبح مشرف إدارة بكامل الصلاحيات؟')) return;
  try { await api(`/admin/users/${id}/promote`, { method: 'PUT' }); toast('تمت الترقية'); loadUsersTable(); }
  catch (e) { toast(e.message, 'error'); }
}
async function deleteUser(id) {
  if (!confirm('حذف هذا العضو نهائيًا؟')) return;
  try { await api(`/admin/users/${id}`, { method: 'DELETE' }); toast('تم حذف العضو'); loadUsersTable(); }
  catch (e) { toast(e.message, 'error'); }
}

// ============== النوافذ المنبثقة (Modals) ==============
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal-overlay').forEach(ov => {
  ov.addEventListener('click', (e) => { if (e.target === ov) ov.classList.remove('open'); });
});

// ============== ربط النماذج ==============
function setupForms() {
  document.getElementById('newsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    fd.set('is_published', form.is_published.checked ? '1' : '0');
    const id = fd.get('id');
    fd.delete('id');
    try {
      if (id) await api(`/news/${id}`, { method: 'PUT', body: fd });
      else await api('/news', { method: 'POST', body: fd });
      toast('تم الحفظ بنجاح');
      closeModal('newsModal');
      loadNewsTable();
    } catch (err) { toast(err.message, 'error'); }
  });

  document.getElementById('playerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    const id = fd.get('id');
    fd.delete('id');
    try {
      if (id) await api(`/players/${id}`, { method: 'PUT', body: fd });
      else await api('/players', { method: 'POST', body: fd });
      toast('تم الحفظ بنجاح');
      closeModal('playerModal');
      loadPlayersTable();
    } catch (err) { toast(err.message, 'error'); }
  });

  document.getElementById('matchForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const id = form.id.value;
    const payload = {
      opponent: form.opponent.value,
      match_date: new Date(form.match_date.value).toISOString(),
      location: form.location.value,
      status: form.status.value,
      score_home: form.score_home.value === '' ? null : Number(form.score_home.value),
      score_away: form.score_away.value === '' ? null : Number(form.score_away.value)
    };
    try {
      if (id) await api(`/matches/${id}`, { method: 'PUT', body: payload });
      else await api('/matches', { method: 'POST', body: payload });
      toast('تم الحفظ بنجاح');
      closeModal('matchModal');
      loadMatchesTable();
    } catch (err) { toast(err.message, 'error'); }
  });

  document.getElementById('generalSettingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api('/settings', { method: 'PUT', body: Object.fromEntries(fd) });
      toast('تم حفظ الإعدادات');
      loadSiteShell('');
    } catch (err) { toast(err.message, 'error'); }
  });

  document.getElementById('sponsorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = Object.fromEntries(fd);
    body.sponsor_enabled = document.getElementById('sponsorEnabled').checked ? '1' : '0';
    try {
      await api('/settings', { method: 'PUT', body });
      toast('تم حفظ إعدادات الراعي');
    } catch (err) { toast(err.message, 'error'); }
  });

  document.getElementById('passwordForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await api('/admin/change-password', { method: 'PUT', body: Object.fromEntries(fd) });
      toast('تم تحديث كلمة المرور');
      e.target.reset();
    } catch (err) { toast(err.message, 'error'); }
  });
}

async function uploadLogo() {
  const input = document.getElementById('logoInput');
  if (!input.files[0]) return toast('اختر صورة أولًا', 'error');
  const fd = new FormData();
  fd.append('logo', input.files[0]);
  try {
    const { url } = await api('/settings/logo', { method: 'POST', body: fd });
    document.getElementById('currentLogo').src = url;
    document.getElementById('sideLogo').src = url;
    toast('تم تحديث الشعار');
  } catch (err) { toast(err.message, 'error'); }
}

async function uploadSponsorLogo() {
  const input = document.getElementById('sponsorLogoInput');
  if (!input.files[0]) return toast('اختر صورة أولًا', 'error');
  const fd = new FormData();
  fd.append('logo', input.files[0]);
  try {
    const { url } = await api('/settings/sponsor-logo', { method: 'POST', body: fd });
    const img = document.getElementById('currentSponsorLogo');
    img.src = url; img.style.display = 'block';
    toast('تم تحديث شعار الراعي');
  } catch (err) { toast(err.message, 'error'); }
}

initAdmin();
