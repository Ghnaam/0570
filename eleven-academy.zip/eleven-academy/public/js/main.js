// ============== أدوات مساعدة عامة ==============
async function api(path, options = {}) {
  const opts = { credentials: 'include', headers: {}, ...options };
  if (opts.body && !(opts.body instanceof FormData)) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  const res = await fetch('/api' + path, opts);
  let data = {};
  try { data = await res.json(); } catch (e) { /* بدون محتوى */ }
  if (!res.ok) throw new Error(data.error || 'حدث خطأ غير متوقع');
  return data;
}

function toast(message, type = 'success') {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.className = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.className = 'toast show' + (type === 'error' ? ' error' : '');
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove('show'), 3000);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr.replace(' ', 'T') + 'Z')) / 1000;
  if (diff < 60) return 'الآن';
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} دقيقة`;
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} ساعة`;
  if (diff < 2592000) return `منذ ${Math.floor(diff / 86400)} يوم`;
  return new Date(dateStr).toLocaleDateString('ar-EG');
}

function formatMatchDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
}

// ============== حالة عامة ==============
window.SITE = { settings: {}, user: null };

async function loadSiteShell(activePage) {
  try {
    const { settings } = await api('/settings');
    window.SITE.settings = settings;
  } catch (e) { /* تجاهل */ }

  try {
    const { user } = await api('/auth/me');
    window.SITE.user = user;
  } catch (e) {
    window.SITE.user = null;
  }

  renderNavbar(activePage);
  renderFooter();
  renderSponsorStrip();
}

function renderNavbar(activePage) {
  const mount = document.getElementById('navbar');
  if (!mount) return;
  const s = window.SITE.settings;
  const user = window.SITE.user;
  const logo = s.club_logo || '/uploads/default-logo.svg';
  const name = s.club_name || 'Eleven';

  const links = [
    { href: '/', key: 'home', label: 'الرئيسية' },
    { href: '/news.html', key: 'news', label: 'الأخبار' },
    { href: '/players.html', key: 'players', label: 'اللاعبون' },
    { href: '/matches.html', key: 'matches', label: 'المباريات' }
  ];

  let userArea = `
    <a class="btn btn-sm" href="/login.html">دخول</a>
    <a class="btn btn-sm btn-solid" href="/register.html">انضم إلينا</a>`;
  if (user) {
    userArea = `
      <span style="color:var(--gray-300); font-size:.9rem;">مرحبًا، ${escapeHtml(user.name)}</span>
      ${user.role === 'admin' ? '<a href="/admin.html" class="btn btn-sm">لوحة الإدارة</a>' : ''}
      <button class="btn btn-sm btn-danger" id="logoutBtn">خروج</button>`;
  }

  mount.innerHTML = `
    <div class="container">
      <a href="/" class="brand"><img src="${logo}" alt="شعار ${escapeHtml(name)}">${escapeHtml(name)}</a>
      <button class="nav-toggle" id="navToggle">☰</button>
      <div class="nav-links" id="navLinks">
        ${links.map(l => `<a href="${l.href}" class="${activePage === l.key ? 'active' : ''}">${l.label}</a>`).join('')}
      </div>
      <div class="nav-user">${userArea}</div>
    </div>`;

  document.getElementById('navToggle')?.addEventListener('click', () => {
    document.getElementById('navLinks').classList.toggle('open');
  });

  document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    await api('/auth/logout', { method: 'POST' });
    location.href = '/';
  });
}

function renderFooter() {
  const mount = document.getElementById('footer');
  if (!mount) return;
  const s = window.SITE.settings;
  mount.innerHTML = `
    <div class="container">
      <div class="brand">${escapeHtml(s.club_name || 'Eleven')}</div>
      <p>${escapeHtml(s.club_description || '')}</p>
      <p style="margin-top:10px;">© ${new Date().getFullYear()} جميع الحقوق محفوظة</p>
    </div>`;
}

function renderSponsorStrip() {
  const mount = document.getElementById('sponsorStrip');
  if (!mount) return;
  const s = window.SITE.settings;
  if (s.sponsor_enabled !== '1' || !s.sponsor_logo) { mount.innerHTML = ''; return; }
  const content = `<img src="${s.sponsor_logo}" alt="${escapeHtml(s.sponsor_name || 'الراعي الرسمي')}">`;
  mount.innerHTML = `
    <div class="sponsor-strip">
      <div class="label">الراعي الرسمي</div>
      ${s.sponsor_link ? `<a href="${escapeHtml(s.sponsor_link)}" target="_blank" rel="noopener noreferrer">${content}</a>` : content}
    </div>`;
}
