const jwt = require('jsonwebtoken');
const db = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

function attachUser(req, res, next) {
  const token = req.cookies && req.cookies.token;
  req.user = null;
  if (token) {
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      const user = db.prepare('SELECT id, name, email, role, avatar, is_banned FROM users WHERE id = ?').get(payload.id);
      if (user && !user.is_banned) {
        req.user = user;
      }
    } catch (e) {
      // توكن غير صالح أو منتهي، يُتجاهل بصمت
    }
  }
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً' });
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً' });
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'هذا الإجراء متاح للإدارة فقط' });
  next();
}

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
}

module.exports = { attachUser, requireAuth, requireAdmin, signToken, JWT_SECRET };
