const multer = require('multer');
const path = require('path');
const crypto = require('crypto');

const allowedTypes = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']);
const allowedExt = new Set(['.jpg', '.jpeg', '.png', '.webp', '.svg']);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', 'public', 'uploads')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = allowedExt.has(ext) ? ext : '.png';
    const unique = crypto.randomBytes(12).toString('hex');
    cb(null, `${Date.now()}-${unique}${safeExt}`);
  }
});

function fileFilter(req, file, cb) {
  if (!allowedTypes.has(file.mimetype)) {
    return cb(new Error('نوع الملف غير مسموح، الأنواع المسموحة: jpg, png, webp, svg'));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 3 * 1024 * 1024, files: 1 } // 3MB كحد أقصى
});

module.exports = upload;
